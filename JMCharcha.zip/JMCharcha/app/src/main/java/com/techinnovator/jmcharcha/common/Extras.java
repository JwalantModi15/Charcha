package com.techinnovator.jmcharcha.common;

public class Extras {
    public static final String USER_ID = "user_id";
    public static final String USER_NAME = "user_name";
    public static final String USER_PHOTO = "user_photo";

    public static final String messageImages = "message_images";
    public static final String messageVideos = "message_videos";
}
